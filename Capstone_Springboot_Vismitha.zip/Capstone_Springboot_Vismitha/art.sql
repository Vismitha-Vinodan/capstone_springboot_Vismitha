create database art;
use art;
create table login(l_id int primary key auto_increment, username varchar(30) unique,password varchar(30), section_id int not null);
create table admintbl(a_id int primary key auto_increment, name varchar(30), username varchar(30), l_id int, foreign key(l_id) references login(l_id));
create table usertbl(u_id int primary key auto_increment, name varchar(30), gender varchar(10), emailid varchar(50),
phone int,address varchar(100), l_id int, foreign key(l_id) references login(l_id));
create table employee(emp_id int primary key auto_increment, name varchar(30), gender varchar(10), emailid varchar(50),
phone int,address varchar(100), l_id int, foreign key(l_id) references login(l_id));
create table artwork(art_id int primary key auto_increment, name varchar(30), image longblob, type varchar(30),emp_id int,
 quantity int, price float, foreign key(emp_id) references employee(emp_id));
create table ordertbl(o_id int primary key auto_increment, art_id int, payment varchar(30), u_id int,
foreign key(art_id) references artwork(art_id), foreign key(u_id) references usertbl(u_id));
create table delivery(d_id int primary key auto_increment, o_id int, art_id int, u_id int,custo_id int, 
foreign key(art_id) references artwork(art_id), foreign key(u_id) references usertbl(u_id),foreign key(o_id) references ordertbl(o_id),
foreign key(custo_id) references ordercustom(o_id));
create table ordercustom(o_id int primary key auto_increment, image longblob, description varchar(50), payment varchar(30), u_id int,
 foreign key(u_id) references usertbl(u_id));
use art;
create table message(id int primary key auto_increment,name varchar(30),dop date, email varchar(30),subject varchar(30),city varchar(30),
country varchar(30), message varchar(100));
alter table usertbl drop gender;
drop table message;
select * from message;
create table ordercnf(oc_id int primary key auto_increment, o_id int, type varchar(30), emp_id int,
  foreign key(emp_id) references employee(emp_id));
  select * from login;
  insert into login(username,password,section_id) values("admin","admin",1);
  select * from usertbl;
  desc usertbl;
  select * from employee;
  select * from ordertbl;
  alter table ordercustom add status varchar(30);
  select * from ordercustom;
  select * from artwork;
  desc artwork;
  show tables;