package com.sts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJsp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
