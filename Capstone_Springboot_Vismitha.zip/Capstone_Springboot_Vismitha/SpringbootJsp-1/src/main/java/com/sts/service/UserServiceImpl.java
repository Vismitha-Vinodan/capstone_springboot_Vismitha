package com.sts.service;

import java.util.List;

import com.sts.entity.User;

public class UserServiceImpl implements UserService{

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEmployee(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUserById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUserById(long id) {
		// TODO Auto-generated method stub
		
	}

}
