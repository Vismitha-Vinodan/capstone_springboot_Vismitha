package com.sts.repository;

import org.springframework.data.repository.CrudRepository;

import com.sts.entity.Employee;


public interface EmployeeRepository extends CrudRepository<Employee, Integer>{

}
