package com.sts.service;

import java.util.List;

import com.sts.entity.User;

public interface UserService {
	List<User> getAllUser();
	void saveEmployee(User user);
	User getUserById(long id);
	void deleteUserById(long id);
}
