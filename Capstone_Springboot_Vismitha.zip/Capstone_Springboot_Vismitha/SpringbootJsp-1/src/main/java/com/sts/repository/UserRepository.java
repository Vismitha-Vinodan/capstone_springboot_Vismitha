package com.sts.repository;

import org.springframework.data.repository.CrudRepository;

import com.sts.entity.User;

public interface UserRepository extends CrudRepository<User, Long>{

}
