package com.sts.service;

import java.util.List;

import com.sts.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee getEmployeeById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEmployeeById(long id) {
		// TODO Auto-generated method stub
		
	}

}
