package com.sts;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.*;

public class DbConn {
	Connection con;
	Statement stmt;
	PreparedStatement pst;

	public DbConn() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/art", "root", "Vijukumari@1971");

			stmt = con.createStatement();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public int insertmessage(String name, String email, String subject, String city, String country, String msg)
			throws SQLException {

		String str = "insert into message(name,dop,email,subject,city,country,message) values('" + name
				+ "',curdate(),'" + email + "','" + subject + "','" + city + "','" + country + "','" + msg + "')";

		stmt.executeUpdate(str);

		return 1;
	}

	public int login(String uname, String pswd) throws SQLException {
		String str = "select section_id from login where username='" + uname + "' and password='" + pswd + "'";
		ResultSet rs = stmt.executeQuery(str);

		if (rs.next())
			return rs.getInt(1);
		else
			return 0;
	}

	public void delete(int id) throws SQLException {
		String str = "delete from reg where id=" + id;
		stmt.executeUpdate(str);
	}

	public ResultSet display() throws SQLException {
		String str = "select * from reg";
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	public void insertuser(String name, String email, int ph, String address, String username, String password)
			throws SQLException {

		String str1 = "insert into login(username,password,section_id) values('" + username + "','" + password + "',3)";
		stmt.executeLargeUpdate(str1);
		String str2 = "select l_id from login where username='" + username + "' and password='" + password + "'";
		ResultSet rs = stmt.executeQuery(str2);
		int lid = 0;
		while (rs.next()) {
			lid = Integer.parseInt(rs.getString(1));

		}
		String str = "insert into usertbl(name,emailid,phone,address,l_id,id) values('" + name + "','" + email + "',"
				+ ph + ",'" + address + "'," + lid + ",3)";
		stmt.executeUpdate(str);
	}

	public void insertemployee(String name, String email, int ph, String address, String username, String password)
			throws SQLException {

		String str1 = "insert into login(username,password,section_id) values('" + username + "','" + password + "',2)";
		stmt.executeLargeUpdate(str1);
		String str2 = "select l_id from login where username='" + username + "' and password='" + password + "'";
		ResultSet rs = stmt.executeQuery(str2);
		int lid = 0;
		while (rs.next()) {
			lid = Integer.parseInt(rs.getString(1));

		}
		String str = "insert into employee(name,emailid,phone,address,l_id,id) values('" + name + "','" + email + "',"
				+ ph + ",'" + address + "'," + lid + ",2)";
		stmt.executeUpdate(str);
	}

	public void deleteemp(int id) throws SQLException {
		String str2 = "select l_id from employee where emp_id=" + id;
		ResultSet rs = stmt.executeQuery(str2);
		int lid = 0;
		while (rs.next()) {
			lid = Integer.parseInt(rs.getString(1));
		}
		String str = "delete from employee where emp_id=" + id;
		stmt.executeUpdate(str);
		String str1 = "delete from employee where l_id=" + lid;
		stmt.executeUpdate(str1);
	}

	public void updatemp(int id, String name, String email, int ph, String address) throws SQLException {
		String str = "update employee set name='" + name + "', emailid='" + email + "', phone=" + ph + ", address='"
				+ address + "' where emp_id=" + id;
		stmt.executeUpdate(str);
	}

	public ResultSet viewempform() throws SQLException {
		String str = "select emp_id, name,emailid,phone,address from employee";
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	public ResultSet viewemp(int id) throws SQLException {
		String str = "select emp_id, name,emailid,phone,address from employee where emp_id=" + id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	// messages
	public ResultSet viewmsgs() throws SQLException {
		String str = "select * from message";
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	public void delmsgs(int id) throws SQLException {
		String str = "delete from message where id=" + id;
		stmt.executeUpdate(str);

	}

	// orders
	public ResultSet vieworder() throws SQLException {
		String str = "select * from ordertbl";
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	public void delorder(int id) throws SQLException {
		String str = "delete from ordertbl where o_id=" + id;
		stmt.executeUpdate(str);

	}

	// custom order
	public ResultSet viewcorder() throws SQLException {
		String str = "select * from ordercustom";
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	public void delcorder(int id) throws SQLException {
		String str = "delete from ordercustom where o_id=" + id;
		stmt.executeUpdate(str);

	}

	// employee profile
	public int sentempid(String uname, String pswd) throws SQLException {
		String str = "select l_id from login where username='" + uname + "' and password='" + pswd + "'";
		ResultSet rs = stmt.executeQuery(str);
		int id = 0;
		while (rs.next()) {
			id = rs.getInt(1);
		}
		return id;
	}
	public int getempid(int lid) throws SQLException {
		String str = "select emp_id from employee where l_id=" + lid;
		ResultSet rs = stmt.executeQuery(str);
		int id = 0;
		while (rs.next()) {
			id = rs.getInt(1);
		}
		return id;
	}

	public ResultSet viewempid(int id) throws SQLException {
		String str = "select * from employee where emp_id=" + id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}

	// update order table
	public void updateordercnf(int id) throws SQLException {
		String str = "update ordertbl set status='confirm' where o_id=" + id;
		stmt.executeUpdate(str);
	}

	public void updateorderdec(int id) throws SQLException {
		String str = "update ordertbl set status='decline' where o_id=" + id;
		stmt.executeUpdate(str);
	}

	// update custom order table
	public void updatecordercnf(int id) throws SQLException {
		String str = "update ordercustom set status='confirm' where o_id=" + id;
		stmt.executeUpdate(str);
	}

	public void updatecorderdec(int id) throws SQLException {
		String str = "update ordercustom set status='decline' where o_id=" + id;
		stmt.executeUpdate(str);
	}
	
	//art work employee
	public ResultSet viewmyart(int id) throws SQLException {
		String str = "select * from artwork where emp_id=" + id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}
	
	//user profile
	public int sentuserid(String uname, String pswd) throws SQLException {
		String str = "select l_id from login where username='" + uname + "' and password='" + pswd + "'";
		ResultSet rs = stmt.executeQuery(str);
		int id = 0;
		while (rs.next()) {
			id = rs.getInt(1);
		}
		return id;
	}
	public int getuserid(int lid) throws SQLException {
		String str = "select u_id from usertbl where l_id=" + lid;
		ResultSet rs = stmt.executeQuery(str);
		int id = 0;
		while (rs.next()) {
			id = rs.getInt(1);
		}
		return id;
	}

	public ResultSet viewuserid(int id) throws SQLException {
		String str = "select * from usertbl where u_id=" + id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}
	public ResultSet uservieworder(int id) throws SQLException {
		String str = "select * from ordertbl where u_id="+id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}
	public ResultSet userviewcorder(int id) throws SQLException {
		String str = "select * from ordercustom where u_id="+id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}
	public ResultSet viewart() throws SQLException {
		String str = "select * from artwork";
		ResultSet rs = stmt.executeQuery(str);
		return rs;
	}
	//place order
	public ResultSet placeorder(int id) throws SQLException {
		String str = "select * from artwork where art_id =" + id;
		ResultSet rs = stmt.executeQuery(str);
		return rs;
		
	}
	public void insertorder(int artid, String payment, int uid, String status) throws SQLException {
		String str = "insert into ordertbl(art_id, payment, u_id, status) values(" + artid + ",'" + payment + "',"
				+ uid + ",'" + status + "')";
		stmt.executeUpdate(str);
	}

	public void insertart(String name, String image, String type, int empid, int qty, float price) throws SQLException, FileNotFoundException {
		String filepath=image.substring(image.lastIndexOf("\\")+1);
		String file ="C:\\Users\\Vismitha Vinodan\\OneDrive\\Desktop\\art\\"+image;
		File imgfile = new File(file);
		FileInputStream fin = new FileInputStream(imgfile);
		PreparedStatement ps = con.prepareStatement("insert into artwork(name, image, type,emp_id,quantity,price) values(?,?,?,?,?,?)");
		ps.setString(1, name);
		ps.setBinaryStream(2,fin,(int)imgfile.length());
		ps.setString(3, type);
		ps.setInt(4, empid);
		ps.setInt(5, qty);
		ps.setFloat(6, price);
		ps.execute();
	}

	public void insertartuser(String image, String desc, String pay, int uid, String status) throws SQLException, FileNotFoundException {
		String filepath=image.substring(image.lastIndexOf("\\")+1);
		String file ="C:\\Users\\Vismitha Vinodan\\OneDrive\\Desktop\\art\\"+image;
		File imgfile = new File(file);
		FileInputStream fin = new FileInputStream(imgfile);
		PreparedStatement ps = con.prepareStatement("insert into ordercustom(image,description,payment,u_id,status) values(?,?,?,?,?)");
		
		ps.setBinaryStream(1,fin,(int)imgfile.length());
		ps.setString(2, desc);
		ps.setString(3, pay);
		ps.setInt(4, uid);
		ps.setString(5, status);
		ps.execute();
		
	}
}
