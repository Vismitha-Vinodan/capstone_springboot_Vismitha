package com.sts.controller;


import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sts.DbConn;

@Controller
public class HelloCntrl {
	@GetMapping({"/","/hello"})
	public String hello(@RequestParam(value="name", defaultValue = "Vismitha", required = true)String name,Model model) {
		model.addAttribute("name",name);
		return "hello";
	}
	@GetMapping("/admin")
	public String admin() {
		return "admin";
	}
	@GetMapping("/empreg")
	public String empreg() {
		return "empreg";
	}
	@GetMapping("/employee")
	public String employee() {
		return "employee";
	}
	@GetMapping("/employeeabout")
	public String employeeabout() {
		return "employeeabout";
	}
	@GetMapping("/viewemployee")
	public String viewemployee() {
		return "viewemployee";
	}
	@GetMapping("/user")
	public String user() {
		return "user";
	}
	@GetMapping("/loginpage")
	public String loginpage() {
		return "login";
	}
	
	@RequestMapping(value="/messageaction", method = RequestMethod.POST)
	public String msg(@RequestParam(value="name")String name,
			@RequestParam(value="email")String email,
			@RequestParam(value="subject")String subject,
			@RequestParam(value="city")String city,
			@RequestParam(value="country")String country,
			@RequestParam(value="message")String msg) throws SQLException {
		DbConn db= new DbConn();
		int i=db.insertmessage(name, email, subject, city, country, msg);
		System.out.println(i);
		return "messageaction";
	}
	@GetMapping("/userreg")
	public String ureg() {
		return "userreg";
	}
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String login(@RequestParam(value="usr")String username,
			@RequestParam(value="pswd")String password) throws SQLException {
		DbConn db = new DbConn();
		int i = db.login(username, password);
		
		if(i==1) 
			return "admin";
		else if(i==2)
			return "employee";
		else if(i==3)
			return "user";
		else
			return "redirect:/";
	}
	@RequestMapping(value="/userregaction", method = RequestMethod.POST)
	public String userregaction(@RequestParam(value="name")String name,
			@RequestParam(value="email")String email,
			@RequestParam(value="ph")String phone,
			@RequestParam(value="address")String address,
			@RequestParam(value="usr")String username,
			@RequestParam(value="pswd")String password) throws SQLException {
		int ph=Integer.parseInt(phone);
		DbConn db= new DbConn();
		db.insertuser(name, email, ph, address, username, password);
		
		return "login";
	}
	@RequestMapping(value="/employeeregaction", method = RequestMethod.POST)
	public String employeeregaction(@RequestParam(value="name")String name,
			@RequestParam(value="email")String email,
			@RequestParam(value="ph")String phone,
			@RequestParam(value="address")String address,
			@RequestParam(value="usr")String username,
			@RequestParam(value="pswd")String password) throws SQLException {
		int ph=Integer.parseInt(phone);
		DbConn db= new DbConn();
		db.insertemployee(name, email, ph, address, username, password);
		
		return "viewemployee";
	}
	
	//editing employee
	@GetMapping("/editemployee")
	public String editemployee() {
		return "editemployee";
	}
	@RequestMapping(value="/editemployeeaction", method = RequestMethod.POST)
	public String editemployeeaction(@RequestParam(value="id")int id,
			@RequestParam(value="name")String name,
			@RequestParam(value="email")String email,
			@RequestParam(value="ph")String phone,
			@RequestParam(value="address")String address) throws SQLException {
		int ph=Integer.parseInt(phone);
		DbConn db= new DbConn();
		db.updatemp(id,name, email, ph, address);
		
		return "viewemployee";
	}
	@RequestMapping(value="/deleteemployeeaction")
	public String deleteemployeeaction(@RequestParam(value="id")int id) throws SQLException {
		
		DbConn db= new DbConn();
		db.deleteemp(id);
		
		return "viewemployee";
	}
	
	//messages
	@GetMapping("/message")
	public String message() {
		return "message";
	}
	@RequestMapping(value="/deletemessageeaction")
	public String deletemessageeaction(@RequestParam(value="id")int id) throws SQLException {
		
		DbConn db= new DbConn();
		db.delmsgs(id);
		
		return "message";
	}
	//order
	@GetMapping("/orderadmin")
	public String order() {
		return "orderadmin";
	}
	@RequestMapping(value="/deleteorderaction")
	public String deleteorderaction(@RequestParam(value="id")int id) throws SQLException {
		
		DbConn db= new DbConn();
		db.delorder(id);
		
		return "orderadmin";
	}
	//custom order
		@GetMapping("/custorderadmin")
		public String corder() {
			return "custorderadmin";
		}
		@RequestMapping(value="/deletecorderaction")
		public String deletecorderaction(@RequestParam(value="id")int id) throws SQLException {
			
			DbConn db= new DbConn();
			db.delcorder(id);
			
			return "custorderadmin";
		}
	//employee
		@GetMapping("/orderemp")
		public String orderemp() {
			return "orderemp";
		}
		@GetMapping("/custorderemp")
		public String custorderemp() {
			return "custorderemp";
		}
		
	//employee custom and order
		@RequestMapping(value="/confirmaction")
		public String confirmaction(@RequestParam(value="id")int id) throws SQLException {
			
			DbConn db= new DbConn();
			db.updateordercnf(id);
			
			return "orderemp";
		}
		@RequestMapping(value="/declineaction")
		public String declineaction(@RequestParam(value="id")int id) throws SQLException {
			
			DbConn db= new DbConn();
			db.updateorderdec(id);
			
			return "orderemp";
		}
		@RequestMapping(value="/cconfirmaction")
		public String cconfirmaction(@RequestParam(value="id")int id) throws SQLException {
			
			DbConn db= new DbConn();
			db.updatecordercnf(id);
			
			return "custorderemp";
		}
		@RequestMapping(value="/cdeclineaction")
		public String cdeclineaction(@RequestParam(value="id")int id) throws SQLException {
			
			DbConn db= new DbConn();
			db.updatecorderdec(id);
			
			return "custorderemp";
		}
		//employee image
		@GetMapping("/artworkemp")
		public String artworkemp() {
			return "artworkemp";
		}
		@GetMapping("/uploadimage")
		public String uploadimage() {
			return "uploadimage";
		}
		@GetMapping("/artworkuser")
		public String artworkuser() {
			return "artworkuser";
		}
		@GetMapping("/delivery")
		public String delivery() {
			return "delivery";
		}
		@GetMapping("/usercustorder")
		public String usercustorder() {
			return "usercustorder";
		}
		@GetMapping("/userabout")
		public String userabout() {
			return "userabout";
		}
		@GetMapping("/placeorder")
		public String placeorder() {
			return "purchase";
		}
		@GetMapping("/placeordermessage")
		public String placeordermessage() {
			return "usercustorder";
		}
		@RequestMapping(value="/placeorderaction", method = RequestMethod.POST)
		public String placeorderaction(@RequestParam(value="artid")int id,
				@RequestParam(value="pay")String pay,
				@RequestParam(value="uid")int uid,
				@RequestParam(value="status")String status) throws SQLException {
			
			DbConn db= new DbConn();
			db.insertorder(id, pay, uid, status);
			
			return "placeordermessage";
		}
		@RequestMapping(value="/uploadaction", method = RequestMethod.POST)
		public String uploadaction(@RequestParam(value="name")String name,
				@RequestParam(value="image")String image,
				@RequestParam(value="type")String type,
				@RequestParam(value="empid")int empid,
				@RequestParam(value="qty")int qty,
				@RequestParam(value="price")float price) throws SQLException, FileNotFoundException {
			
			DbConn db= new DbConn();
			db.insertart(name,image,type,empid,qty,price);
			
			return "uploadaction";
		}
		@RequestMapping(value="/useruploadaction", method = RequestMethod.POST)
		public String useruploadaction(@RequestParam(value="image")String image,
				@RequestParam(value="desc")String desc,
				@RequestParam(value="pay")String pay,
				@RequestParam(value="uid")int uid,
				@RequestParam(value="status")String status) throws SQLException, FileNotFoundException {
			
			DbConn db= new DbConn();
			db.insertartuser(image,desc,pay,uid,status);
			
			return "useruploadaction";
		}
		@GetMapping("/logout")
		public String logout() {
			return "redirect:/";
		}
}
